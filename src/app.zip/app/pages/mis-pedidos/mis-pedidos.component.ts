import { Component } from '@angular/core';

@Component({
  selector: 'ngx-cat-elements',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class MisPedidosComponent {
}
